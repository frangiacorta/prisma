# Prisma Studio

Editor web per forme astratte, materiali a strati, ambienti, luci 3D anche interne e wallpaper statici o animati.

## Avvio locale

Serve un browser con WebGL 2 e un server HTTP locale. Con Python:

```sh
python -m http.server 4173 --directory dist
```

Apri http://localhost:4173. Non serve compilare il progetto.

## File principali

- dist/index.html e dist/style.css: pagina e interfaccia responsive.
- dist/app.js: editor, galleria locale ed esportazioni.
- dist/renderer.js: renderer autosufficiente, SDF, rifrazione, pellicola spettrale, illuminazione e accumulo.
- dist/model.js: forme e configurazioni precedenti.
- dist/studio-model.js: materiali, palette, ambienti, luci e parametri.
- dist/creative-model.js: creazioni curate, varianti, loop e normalizzazione dei salvataggi.
- dist/panels.js: pannelli di controllo.
- dist/encoder-worker.js e dist/vendor/: codifica video.

## Compatibilità

Le configurazioni precedenti usano la versione originale del renderer. I nuovi materiali e gli ambienti attivano la resa a strati. I wallpaper HTML esportati includono il renderer e funzionano offline.

SSS e caustiche sono approssimazioni geometriche per il rendering in tempo reale. Il video per iPhone va convertito in Live Photo per la schermata di blocco.

## Condivisione in lettura

L'archivio contiene il codice dell'app e questo README. Puoi inviarlo oppure caricarlo in un repository GitHub pubblico; i permessi di scrittura restano separati.
